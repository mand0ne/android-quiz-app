package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class DodajKategorijuAkt extends AppCompatActivity  implements IconDialog.Callback {

    private EditText etNaziv;
    private EditText etIkona;
    private Button btnDodajKategoriju;
    private Button btnDodajIkonu;
    private Icon[] selectedIcons;
    private boolean sveOk1 = true;
    private boolean sveOk2 = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        etNaziv = (EditText)findViewById(R.id.etNaziv);
        etIkona = (EditText)findViewById(R.id.etIkona);
        btnDodajKategoriju = (Button)findViewById(R.id.btnDodajKategoriju);
        btnDodajIkonu = (Button) findViewById(R.id.btnDodajIkonu);



        final IconDialog iconDialog = new IconDialog();
        btnDodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        etIkona.setFocusable(false);


        btnDodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Kategorija kat = new Kategorija(etNaziv.getText().toString(), Integer.toString(selectedIcons[0].getId()));
                etIkona.setText(Integer.toString(selectedIcons[0].getId()));
                Intent intent = new Intent(DodajKategorijuAkt.this, KvizoviAkt.class);
                //intent.putExtra("Novakategorija", kat);
                DodajKategorijuAkt.this.startActivity(intent);




            }
        });

    }



    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
    }

}

