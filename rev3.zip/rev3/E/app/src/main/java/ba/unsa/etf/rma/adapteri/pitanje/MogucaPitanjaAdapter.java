package ba.unsa.etf.rma.adapteri.pitanje;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class MogucaPitanjaAdapter extends ArrayAdapter<Pitanje> {
    private ArrayList<Pitanje> pitanja;

    public MogucaPitanjaAdapter(Context context, int resource, ArrayList<Pitanje> pitanja) {
        super(context, resource, pitanja);
        this.pitanja = pitanja;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View novi = convertView;
        LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        novi = layoutInflater.inflate(R.layout.element_liste, null);

        ImageView imageView = novi.findViewById(R.id.listaIkona);
        imageView.setImageResource(R.drawable.zelenikrug);

        TextView textView = novi.findViewById(R.id.listaNaziv);
        textView.setText(pitanja.get(position).getNaziv());

        return novi;
    }
}
