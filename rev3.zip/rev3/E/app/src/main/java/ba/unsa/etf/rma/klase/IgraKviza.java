package ba.unsa.etf.rma.klase;

public class IgraKviza implements Comparable<IgraKviza>{
    private String idKviza;
    private String imeIgraca;
    private double procenat;

    public IgraKviza(String idKviza, String imeIgraca, double procenat) {
        this.idKviza = idKviza;
        this.imeIgraca = imeIgraca;
        this.procenat = procenat;
    }

    public String getIdKviza() {
        return idKviza;
    }

    public void setIdKviza(String idKviza) {
        this.idKviza = idKviza;
    }

    public String getImeIgraca() {
        return imeIgraca;
    }

    public void setImeIgraca(String imeIgraca) {
        this.imeIgraca = imeIgraca;
    }

    public double getProcenat() {
        return procenat;
    }

    public void setProcenat(double procenat) {
        this.procenat = procenat;
    }

    @Override
    public boolean equals(Object igra) {
        if(!(igra instanceof IgraKviza)) return false;

        return idKviza.equals(((IgraKviza) igra).idKviza) && imeIgraca.equals(((IgraKviza) igra).imeIgraca) && procenat == ((IgraKviza) igra).procenat;
    }


    @Override
    public int compareTo(IgraKviza igraKviza) {
        if(igraKviza.procenat < procenat) return 1;
        else if(igraKviza.procenat > procenat) return -1;
        return imeIgraca.compareTo(igraKviza.imeIgraca);
    }
}
