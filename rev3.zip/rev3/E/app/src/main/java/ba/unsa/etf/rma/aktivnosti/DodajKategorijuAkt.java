package ba.unsa.etf.rma.aktivnosti;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.IBaza;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {
    private EditText nazivKategorije;
    private EditText nazivIkone;
    private Button dodajIkonuBtn;
    private Button dodajKategorijuBtn;
    private Icon[] selektovaneIkone;
    private Kategorija kategorija;

    private void inicijalizirajPoglede() {
        nazivKategorije = findViewById(R.id.etNaziv);
        nazivIkone = findViewById(R.id.etIkona);
        dodajIkonuBtn = findViewById(R.id.btnDodajIkonu);
        dodajKategorijuBtn = findViewById(R.id.btnDodajKategoriju);

        nazivIkone.setEnabled(false);
    }


    private boolean validirajNazivIkone() {
        if (nazivIkone.length() == 0 || selektovaneIkone == null || selektovaneIkone.length == 0) {
            nazivIkone.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
            Toast.makeText(this, "Niste odabrali ikonu", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void vratiBojuPozadine(final EditText editText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                return;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                editText.setBackgroundResource(R.drawable.edit_text_button_dizajn);
            }

            @Override
            public void afterTextChanged(Editable s) {
                return;
            }
        });
    }

    private void spasiKategoriju() {
        dodajKategorijuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validirajNazivIkone())
                    new UcitajKategorijeZaValidacijuTask(v.getContext()).execute("Validacija kategorija");
            }
        });
    }

    private void dodajIkonu() {
        dodajIkonuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vratiBojuPozadine(nazivIkone);
                final IconDialog iconDialog = new IconDialog();
                iconDialog.setMaxSelection(1, false);
                iconDialog.setSelectedIcons(selektovaneIkone);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_kategoriju_akt);

        inicijalizirajPoglede();
        spasiKategoriju();
        dodajIkonu();

        vratiBojuPozadine(nazivKategorije);
        vratiBojuPozadine(nazivIkone);
    }


    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selektovaneIkone = icons;
        nazivIkone.setText("" + selektovaneIkone[0].getId());
    }

    @Override
    public void onBackPressed() {
        Intent vratiDodajKvizAkt = new Intent(DodajKategorijuAkt.this, DodajKvizAkt.class);
        vratiDodajKvizAkt.putExtra("kvizId", getIntent().getStringExtra("kvizId"));
        vratiDodajKvizAkt.putExtra("noviNazivKviza", getIntent().getStringExtra("noviNazivKviza"));
        vratiDodajKvizAkt.putExtra("dodanaPitanja", getIntent().getSerializableExtra("dodanaPitanja"));
        DodajKategorijuAkt.this.startActivity(vratiDodajKvizAkt);
    }

    public class UcitajKategorijeZaValidacijuTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection conn;
        private Context context;
        private ProgressDialog progressDialog = null;
        private ArrayList<Kategorija> kategorijeIzBaze = new ArrayList<>();

        private boolean validirajNazivKategorije() {
            if (nazivKategorije.length() == 0) {
                nazivKategorije.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
                Toast.makeText(context, "Niste unijeli naziv kategorije", Toast.LENGTH_SHORT).show();
                return false;
            }

            for (Kategorija kategorija : kategorijeIzBaze) {
                if (nazivKategorije.getText().toString().equals(kategorija.getNaziv())) {
                    nazivKategorije.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
                    Toast.makeText(context, "Kategorija vec postoji u bazi", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }

            return true;
        }

        public UcitajKategorijeZaValidacijuTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();
                try {
                    kategorijeIzBaze.clear();
                    JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(conn.getInputStream()));
                    if (dokumenti.has("documents")) {
                        JSONArray array = dokumenti.getJSONArray("documents");
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject kategorijaNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject kategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idIkonice");
                            String naziv = kategorijaNaziv.getString("stringValue");
                            String id = ((Integer) kategorijaId.getInt("integerValue")).toString();
                            kategorijeIzBaze.add(new Kategorija(naziv, id, name[name.length - 1]));
                        }
                    }
                    kategorijeIzBaze.add(0, new Kategorija("Sve", "902", "0"));

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Validacija kategorije u toku", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            if (validirajNazivKategorije()) {
                kategorija = new Kategorija(nazivKategorije.getText().toString(), nazivIkone.getText().toString(), "");
                new DodajKategorijuTask(context).execute("Dodavanje kategorije");

            }
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }

    public class DodajKategorijuTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection conn;
        private Context context;
        private ProgressDialog progressDialog;

        public DodajKategorijuTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + kategorija.getNaziv() + "\"}, \"idIkonice\": {\"integerValue\":\"" + kategorija.getId().trim() + "\"}}}";
                OutputStream os = conn.getOutputStream();
                byte[] input = dokument.getBytes("utf-8");
                os.write(input, 0, input.length);


                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }


            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Dodajem kategoriju u bazu", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            Toast.makeText(context, "Kategorija \"" + kategorija.getNaziv() + "\" dodana u bazu", Toast.LENGTH_SHORT).show();
            Intent vratiDodajKvizAkt = new Intent(DodajKategorijuAkt.this, DodajKvizAkt.class);
            vratiDodajKvizAkt.putExtra("nazivNoveKategorije", nazivKategorije.getText().toString());
            vratiDodajKvizAkt.putExtra("kvizId", getIntent().getStringExtra("kvizId"));
            vratiDodajKvizAkt.putExtra("noviNazivKviza", getIntent().getStringExtra("noviNazivKviza"));
            vratiDodajKvizAkt.putExtra("dodanaPitanja", getIntent().getSerializableExtra("dodanaPitanja"));
            DodajKategorijuAkt.this.startActivity(vratiDodajKvizAkt);
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();

            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }

}
