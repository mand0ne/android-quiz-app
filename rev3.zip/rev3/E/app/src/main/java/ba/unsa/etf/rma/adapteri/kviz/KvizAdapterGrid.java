package ba.unsa.etf.rma.adapteri.kviz;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

public class KvizAdapterGrid extends ArrayAdapter<Kviz> {
    private ArrayList<Kviz> kvizovi;

    public KvizAdapterGrid( Context context, int resource, ArrayList<Kviz> kvizovi) {
        super(context, resource, kvizovi);
        this.kvizovi = kvizovi;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final View novi;
        final LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        novi = layoutInflater.inflate(R.layout.element_grid, null);
        final ImageView imageView = novi.findViewById(R.id.gridIkona);
        final IconHelper iconHelper = IconHelper.getInstance(novi.getContext());
        iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
            @Override
            public void onDataLoaded() {
                if(kvizovi.get(position).getKategorija() != null) imageView.setImageDrawable(iconHelper.getIcon(Integer.parseInt(kvizovi.get(position).getKategorija().getId())).getDrawable(getContext()));
                else imageView.setImageResource(R.drawable.zelenikrug);
                notifyDataSetChanged();
            }
        });


        TextView textView = novi.findViewById(R.id.gridNaziv);
        textView.setText(kvizovi.get(position).getNaziv());


        textView = novi.findViewById(R.id.gridBrojPitanja);
        textView.setText(position == kvizovi.size() - 1 ? "" : kvizovi.get(position).getPitanja().size() + "");

        return novi;
    }
}
