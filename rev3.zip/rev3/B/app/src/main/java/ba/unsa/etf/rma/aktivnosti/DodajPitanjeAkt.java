package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {
    ListView lvOdgovori;
    Button btnDodajPitanje;
    Button btnDodajTacan;
    Button btnDodajOdgovor;
    EditText etOdgovor;
    EditText etNaziv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);


        btnDodajPitanje = (Button) findViewById(R.id.btnDodajPitanje);
        btnDodajTacan = (Button) findViewById(R.id.btnDodajTacan);
        btnDodajOdgovor = (Button) findViewById(R.id.btnDodajOdgovor);
        etOdgovor = (EditText) findViewById(R.id.etOdgovor);
        etNaziv = (EditText) findViewById(R.id.etNaziv);
        lvOdgovori = (ListView) findViewById(R.id.lvOdgovori);

        final ArrayList<String> odgovori = new ArrayList<String>();
        final ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, odgovori);
        lvOdgovori.setAdapter(adapter);

        btnDodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odgovori.add(0, etOdgovor.getText().toString());
                adapter.notifyDataSetChanged();
                etOdgovor.setText("");
            }
        });

        btnDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odgovori.add(0, etOdgovor.getText().toString());
                adapter.notifyDataSetChanged();
                btnDodajTacan.setText("");
                lvOdgovori.getChildAt(0).setBackgroundResource(R.color.green);

            }
        });

        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                odgovori.remove(position);
                adapter.notifyDataSetChanged();
            }
        });

        btnDodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Pitanje p = new Pitanje(etNaziv.getText().toString(),etNaziv.getText().toString(), odgovori, odgovori.get(0));
                Intent povratak = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);
                //povratak.putExtra("novoPitanje", p);
                //povratak.putExtra("novo", true);
                DodajPitanjeAkt.this.startActivity(povratak);
            }
        });
    }

}
