package ba.unsa.etf.rma.aktivnosti;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.IBaza;
import ba.unsa.etf.rma.IzgledListView;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {
    private EditText etOdgovor;
    private EditText etPitanje;

    private Button dodajOdgovorBtn;
    private Button dodajTacanBtn;
    private Button dodajPitanjeBtn;

    private ListView lvOdgovori;
    private ArrayAdapter<String> odgovoriAdapter;
    private ArrayList<String> odgovori = new ArrayList<>();

    private String tacanOdgovor = null;
    private Pitanje novoPitanje;


    private void inicijalizirajListu(){
        lvOdgovori = findViewById(R.id.lvOdgovori);
        odgovoriAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, odgovori){
            @Override
            public View getView(int position, View convertView, ViewGroup parent){
                View view = super.getView(position, convertView, parent);
                if(odgovori.get(position).equals(tacanOdgovor)) view.setBackgroundColor(getResources().getColor(R.color.zelena));
                else view.setBackgroundColor(Color.parseColor("#FAFAFA"));
                return view;
            }
        };
        lvOdgovori.setAdapter(odgovoriAdapter);
        IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(lvOdgovori);
    }

    private void inicijalizirajPoglede(){
        etOdgovor = findViewById(R.id.etOdgovor);
        etPitanje = findViewById(R.id.etNaziv);

        dodajTacanBtn = findViewById(R.id.btnDodajTacan);
        dodajOdgovorBtn = findViewById(R.id.btnDodajOdgovor);
        dodajPitanjeBtn = findViewById(R.id.btnDodajPitanje);

        inicijalizirajListu();
    }

    private boolean daLiJeDodanTacanOdgovor(){
        if(tacanOdgovor == null){
            dodajTacanBtn.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
            Toast.makeText(this, "Nije dodan tacan odgovor", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }



    private boolean daLiJeDodanJedanNetacan(){
        if(odgovori.size() < 2){
            dodajOdgovorBtn.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
            Toast.makeText(this, "Nije dodan nijedan netacan odgovor", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void spasiPitanje(){
        dodajPitanjeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean sveValidno = true;
                if(!daLiJeDodanTacanOdgovor()) sveValidno = false;
                if(!daLiJeDodanJedanNetacan()) sveValidno = false;

                if(sveValidno)
                    new UcitajPitanjaZaValidacijuTask(v.getContext()).execute("Validacija pitanja");

            }
        });
    }

    private void obrisiOdgovor(){
        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(odgovori.get(position).equals(tacanOdgovor)) tacanOdgovor = null;
                odgovori.remove(position);
                odgovoriAdapter.notifyDataSetChanged();
                IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(lvOdgovori);
            }
        });
    }

    private boolean validirajOdgovor(){
        if(etOdgovor.getText().toString().length() == 0) {
            etOdgovor.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
            Toast.makeText(this, "Niste unijeli odgovor", Toast.LENGTH_SHORT).show();

            return false;
        }
        for(String odgovor : odgovori){
            if(odgovor.equals(etOdgovor.getText().toString())){
                etOdgovor.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
                Toast.makeText(this, "Odgovor vec postoji u pitanju", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    private void dodajOdgovor(){
        dodajOdgovorBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dodajOdgovorBtn.setBackgroundResource(R.drawable.edit_text_button_dizajn);
                if(validirajOdgovor()){
                    odgovori.add(etOdgovor.getText().toString());
                    odgovoriAdapter.notifyDataSetChanged();
                    IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(lvOdgovori);
                    etOdgovor.setText("");
                }

            }
        });
    }



    private void dodajTacanOdgovor(){
        dodajTacanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dodajTacanBtn.setBackgroundResource(R.drawable.edit_text_button_dizajn);
                if(validirajOdgovor() && tacanOdgovor == null) {
                    tacanOdgovor = etOdgovor.getText().toString();

                    odgovori.add(etOdgovor.getText().toString());
                    odgovoriAdapter.notifyDataSetChanged();
                    IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(lvOdgovori);
                    etOdgovor.setText("");
                }

            }
        });
    }

    private void vratiBojuPozadine(final EditText editText){
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                return;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                editText.setBackgroundResource(R.drawable.edit_text_button_dizajn);
            }

            @Override
            public void afterTextChanged(Editable s) {
                return;
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_pitanje_akt);

        inicijalizirajPoglede();

        dodajOdgovor();
        dodajTacanOdgovor();

        vratiBojuPozadine(etOdgovor);
        vratiBojuPozadine(etPitanje);

        obrisiOdgovor();
        spasiPitanje();
    }

    @Override
    public void onBackPressed() {
        Intent vratiNaDodajKvizAkt = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);

        vratiNaDodajKvizAkt.putExtra("noviNazivKviza", getIntent().getStringExtra("noviNazivKviza"));
        vratiNaDodajKvizAkt.putExtra("dodanaPitanja", getIntent().getSerializableExtra("dodanaPitanja"));
        vratiNaDodajKvizAkt.putExtra("kvizId", getIntent().getStringExtra("kvizId"));
        vratiNaDodajKvizAkt.putExtra("idKategorije", getIntent().getStringExtra("idKategorije"));
        DodajPitanjeAkt.this.startActivity(vratiNaDodajKvizAkt);
    }

    public class UcitajPitanjaZaValidacijuTask extends AsyncTask<String, Void, Void> implements IBaza {
        private Context context;
        private ArrayList<Pitanje> svaPitanja = new ArrayList<>();
        private HttpURLConnection conn;
        private ProgressDialog progressDialog;

        private boolean validirajNazivPitanja(){
            if(etPitanje.getText().toString().length() == 0) {
                etPitanje.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
                Toast.makeText(context, "Niste unijeli naziv pitanja", Toast.LENGTH_SHORT).show();
                return false;
            }

            for(Pitanje pitanje : svaPitanja){
                if(pitanje.getNaziv().equals(etPitanje.getText().toString())){
                    etPitanje.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
                    Toast.makeText(context, "Pitanje vec postoji u bazi", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }


            return true;
        }

        public UcitajPitanjaZaValidacijuTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();
                JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(conn.getInputStream()));
                if(dokumenti.has("documents")){
                    JSONArray array = dokumenti.getJSONArray("documents");
                    for (int i = 0; i < array.length(); i++) {
                        String[] name = array.getJSONObject(i).getString("name").split("/");
                        JSONObject pitanjeNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                        JSONObject indexTacnog = array.getJSONObject(i).getJSONObject("fields").getJSONObject("indexTacnog");
                        JSONArray odgovoriJSON = array.getJSONObject(i).getJSONObject("fields").getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                        ArrayList<String> odgovori = new ArrayList<>();
                        for (int j = 0; j < odgovoriJSON.length(); j++)
                            odgovori.add(odgovoriJSON.getJSONObject(j).getString("stringValue"));
                        String naziv = pitanjeNaziv.getString("stringValue");
                        Integer tacan = indexTacnog.getInt("integerValue");
                        svaPitanja.add(new Pitanje(naziv, naziv, odgovori, odgovori.get(tacan), name[name.length - 1]));
                    }
                }

            } catch (IOException e) {
                zatvoriKonekciju();
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Validacija pitanja u toku", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            if(validirajNazivPitanja()){
                novoPitanje = new Pitanje(etPitanje.getText().toString(), etPitanje.getText().toString(), odgovori, tacanOdgovor, null);
                new DodajPitanjeTask(context).execute("Dodavanje pitanja");
            }

        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Pitanja?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }

    public class DodajPitanjeTask extends AsyncTask<String, Void, Void> implements IBaza {
        private Context context;
        private HttpURLConnection conn;
        private ProgressDialog progressDialog;

        public DodajPitanjeTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();

                int pozicija = 0;

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + novoPitanje.getNaziv() + "\"}, \"odgovori\": {\"arrayValue\": {\"values\": [";
                for(int i = 0; i < novoPitanje.getOdgovori().size(); i++){
                    if(novoPitanje.getOdgovori().get(i).equals(novoPitanje.getTacan())) pozicija = i;
                    dokument += "{\"stringValue\": \"" + novoPitanje.getOdgovori().get(i) + "\"}";
                    if(i != novoPitanje.getOdgovori().size() - 1) dokument += ", ";
                }

                dokument += "]}}, \"indexTacnog\": {\"integerValue\":\"" + pozicija + "\"}}}";
                OutputStream os = conn.getOutputStream();
                byte[] input = dokument.getBytes("utf-8");
                os.write(input, 0, input.length);


                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) !=null ) {
                    response.append(responseLine.trim());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Dodajem pitanje u bazu", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            Toast.makeText(context, "Pitanje dodano u bazu", Toast.LENGTH_SHORT).show();

            Intent vratiNaDodajKvizAkt = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);
            vratiNaDodajKvizAkt.putExtra("nazivNovogPitanja", novoPitanje.getNaziv());
            vratiNaDodajKvizAkt.putExtra("dodanaPitanja", getIntent().getSerializableExtra("dodanaPitanja"));
            vratiNaDodajKvizAkt.putExtra("kvizId", getIntent().getStringExtra("kvizId"));
            vratiNaDodajKvizAkt.putExtra("noviNazivKviza", getIntent().getStringExtra("noviNazivKviza"));
            vratiNaDodajKvizAkt.putExtra("idKategorije", getIntent().getStringExtra("idKategorije"));
            DodajPitanjeAkt.this.startActivity(vratiNaDodajKvizAkt);

        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Pitanja?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();

            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }
}
