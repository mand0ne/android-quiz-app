package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKvizAkt extends AppCompatActivity {

    private ListView lvDodanaPitanja;
    private ListView lvMogucaPitanja;
    private Spinner spKategorije;
    private EditText etNaziv;
    private Button btnDodajKviz;


    private ArrayList<Pitanje> dajSve(ArrayList<Kviz> k){
        ArrayList<Pitanje> sve = new ArrayList<>();
        for(Kviz x: k){
            for(Pitanje p: x.getPitanja()){
                sve.add(p);
            }
        }
        return sve;
    }
    private ArrayList<Pitanje> dajMoguca(ArrayList<Kviz> k, Kviz kv){
        ArrayList<Pitanje> sve = dajSve(k);
        ArrayList<Pitanje> moguca = new ArrayList<Pitanje>();
        for(Pitanje x: sve){
            for(Pitanje y: kv.getPitanja()){
                if(!x.getNaziv().equals(y.getNaziv()))
                    moguca.add(x);
            }
        }
        return moguca;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        Intent intent = getIntent();
        final ArrayList<Kviz> kvizovi = (ArrayList<Kviz>) intent.getSerializableExtra("kvizovi");
        ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();ArrayList<Pitanje> dodanaPitanja = new ArrayList<>();
        ArrayAdapter<Pitanje> adapterMogucaPitanja;
        ArrayAdapter<Pitanje> adapterDodanaPitanja;
        Kviz novi;
        etNaziv = (EditText) findViewById(R.id.etNaziv);
        lvDodanaPitanja = (ListView) findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = (ListView) findViewById(R.id.lvMogucaPitanja);

        dodanaPitanja.add(new Pitanje("Dodaj Pitanje",null,null,null));
       
        adapterDodanaPitanja = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dodanaPitanja);
        lvDodanaPitanja.setAdapter(adapterDodanaPitanja);
        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(i==0) {
                    Intent intent = new Intent(DodajKvizAkt.this,DodajPitanjeAkt.class);
                    DodajKvizAkt.this.startActivity(intent);
                }

            }
        });

        //spinner
        spKategorije = (Spinner) findViewById(R.id.spKategorije);
        final ArrayList<Kategorija> kat = (ArrayList<Kategorija>) getIntent().getSerializableExtra("Kategorije");
        kat.add(new Kategorija("Dodaj kategoriju", "-1"));
        ArrayAdapter<Kategorija> adapterKategorije = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kat);
        adapterKategorije.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spKategorije.setAdapter(adapterKategorije);
        adapterKategorije.notifyDataSetChanged();
        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                if (i == kat.size() - 1) {
                    DodajKvizAkt.this.startActivity(intent);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        //dugme za dodavanje
        Button btnDodajKviz = (Button) findViewById(R.id.btnDodajKviz);
        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Kviz novi = new Kviz(etNaziv.getText().toString(), dajSve(kvizovi), (Kategorija)spKategorije.getSelectedItem());
                Intent intent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                //intent.putExtra("NoviKviz", novi);
                DodajKvizAkt.this.startActivity(intent);
            }
        });

    }


}
