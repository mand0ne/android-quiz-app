package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviAkt extends AppCompatActivity {

    Spinner spPostojeceKategorije;
    ListView lvKvizovi;
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    final ArrayList<Kviz> kvizovi = new ArrayList<>();




    //Incijalizacija spinner-a i listview-a
    private void initializeViews(){

        spPostojeceKategorije = (Spinner)findViewById(R.id.spPostojeceKategorije);
        ArrayAdapter<Kategorija> adapterKategorije = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategorije);
        adapterKategorije.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPostojeceKategorije.setAdapter(adapterKategorije);

        lvKvizovi = (ListView)findViewById(R.id.lvKvizovi);
        lvKvizovi.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, kvizovi));

        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long itemID) {
                if (position >= 0 && position < kategorije.size()) {
                    getSelectedCategoryData(position);
                } else {
                    Toast.makeText(KvizoviAkt.this, "Izabrana kategorija ne postoji!", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private ArrayList<Pitanje> dajPitanja(){
        final ArrayList<String> odgovori = new ArrayList<>();
        odgovori.add("Da");
        odgovori.add("Ne");
        odgovori.add("Ne znam");
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        pitanja.add(new Pitanje("Pitanje 1", "abc", odgovori, "Da"));
        pitanja.add(new Pitanje("Pitanje 2", "abc", odgovori, "Ne"));
        pitanja.add(new Pitanje("Pitanje 3", "abc", odgovori, "Ne"));
        pitanja.add(new Pitanje("Pitanje 4", "abc", odgovori, "Da"));

        ArrayList<Pitanje> nova = new ArrayList<>();
        nova.add(new Pitanje("Pitanje 5", "koje", odgovori, "Jeste1"));
        nova.add(new Pitanje("Pitanje 6", "koje2", odgovori, "Jeste2"));
        nova.add(new Pitanje("Pitanje 7", "koje3", odgovori, "Jeste3"));
        nova.add(new Pitanje("Pitanje 8", "koje3", odgovori, "Jeste3"));
        return pitanja;
    }

    //Unos podataka  koristenih za testiranje
    private void unosPodataka(){

        final ArrayList<String> odgovori = new ArrayList<>();
        odgovori.add("Da");
        odgovori.add("Ne");
        odgovori.add("Ne znam");
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        pitanja.add(new Pitanje("Pitanje 1", "abc", odgovori, "Da"));
        pitanja.add(new Pitanje("Pitanje 2", "abc", odgovori, "Ne"));
        pitanja.add(new Pitanje("Pitanje 3", "abc", odgovori, "Ne"));
        pitanja.add(new Pitanje("Pitanje 4", "abc", odgovori, "Da"));

        ArrayList<Pitanje> nova = new ArrayList<>();
        nova.add(new Pitanje("Pitanje 5", "koje", odgovori, "Jeste1"));
        nova.add(new Pitanje("Pitanje 6", "koje2", odgovori, "Jeste2"));
        nova.add(new Pitanje("Pitanje 7", "koje3", odgovori, "Jeste3"));
        nova.add(new Pitanje("Pitanje 8", "koje3", odgovori, "Jeste3"));

        kategorije.add(new Kategorija("Svi", "0"));
        kategorije.add(new Kategorija("Sport", "1"));
        kategorije.add(new Kategorija("Geografija", "2"));
        kategorije.add(new Kategorija("Historija", "3"));

        kvizovi.add(new Kviz("Dodaj Kviz", null, kategorije.get(0)));
        kvizovi.add(new Kviz("Kviz 1 - Sport", pitanja, kategorije.get(1)));
        kvizovi.add(new Kviz("Kviz 2 - Sport", pitanja, kategorije.get(1)));
        kvizovi.add(new Kviz("Kviz 3 - Sport", nova, kategorije.get(1)));
        kvizovi.add(new Kviz("Kviz 4 - Geografija", nova, kategorije.get(2)));
    }

    private void getSelectedCategoryData(int x ) {

        ArrayList<Kviz> kvizovi2 = new ArrayList<>();
        ArrayAdapter<Kviz> adapterKviz;
        if(x == 0){
            adapterKviz = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, kvizovi);
            lvKvizovi.setAdapter(adapterKviz);
        }
        else{

            for (Kviz k : kvizovi) {
                int tmp = Integer.parseInt(k.getKategorija().getId());
                if(tmp == 0){
                    kvizovi2.add(k);
                    continue;
                }
                if( tmp == x){
                    kvizovi2.add(k);
                }
            }
            adapterKviz = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, kvizovi2);
            lvKvizovi.setAdapter(adapterKviz);

        }
        adapterKviz.notifyDataSetChanged();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        unosPodataka();
        initializeViews();



        lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position == 0) {
                    Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                    //myIntent.putExtra("Pitanja", dajPitanja());
                    myIntent.putExtra("Kategorije", kategorije);
                    myIntent.putExtra("Kvizovi", kvizovi);
                    myIntent.putExtra("Novi", true);
                    KvizoviAkt.this.startActivity(myIntent);
                }

                else{
                    Intent postojeciKviz = new Intent(KvizoviAkt.this, DodajKvizAkt.class);

                    postojeciKviz.putExtra("Edit", true);
                    //postojeciKviz.putExtra("Pitanja", dajPitanja());
                    postojeciKviz.putExtra("kviz", kvizovi.get(position));
                    postojeciKviz.putExtra("Kategorije", kategorije);
                    postojeciKviz.putExtra("Kvizovi", kvizovi);
                    KvizoviAkt.this.startActivity(postojeciKviz);
                }
            }
        });



//                Intent intent = getIntent();
//                Kategorija nova = (Kategorija) intent.getSerializableExtra("Novakategorija");
//                kategorije.add(nova);

    }
}

