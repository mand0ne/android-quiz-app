package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKategorijuAkt;

public class CustomAdapterKviz extends ArrayAdapter<Kviz> {

    private Context mContext;
    private int resources;
    private ArrayList<Kviz> kvizovi;
    private EditText editText;

    public CustomAdapterKviz(Context context, int res, ArrayList<Kviz> kvizovi2) {
        super(context, res, kvizovi2);
        mContext = context;
        resources = res;
        kvizovi = kvizovi2;
    }



    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(R.layout.lista, parent, false);
        View view = inflater.inflate(R.layout.activity_main, null);

        final ImageView imageView = (ImageView) convertView.findViewById(R.id.ikonaKviza);
        TextView textView = (TextView) convertView.findViewById(R.id.nazivTeksta);
        final Kviz kvizic = kvizovi.get(position);
        textView.setText(kvizic.getNaziv());
        if (kvizic.getKategorija().getIndikator()==0 && position!=kvizovi.size()-1)
            imageView.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_notification_overlay));
        else if (position==kvizovi.size()-1)
            imageView.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_input_add));
        else
            {
                    //Toast.makeText(getContext(), ""+kvizic.getSlikaKviza(), Toast.LENGTH_SHORT).show();
                    final IconHelper iconHelper = IconHelper.getInstance(getContext());
                    iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                        @Override
                        public void onDataLoaded() {
                            // This happens on UI thread, and is guaranteed to be called.
                            imageView.setImageDrawable(iconHelper.getIcon(kvizic.getSlikaKviza()).getDrawable(mContext));
                        }
                    });
        }
       /* row = inflater.inflate(R.layout.lista, parent, false);
        TextView title;
        ImageView i1 = (ImageView) row.findViewById(R.id.imgIcon);
        title = (TextView) row.findViewById(R.id.txtTitle);
        title.setText(imge.get(position));
        i1.setImageResource(imge[position]);
*/
       return convertView;
    }
}